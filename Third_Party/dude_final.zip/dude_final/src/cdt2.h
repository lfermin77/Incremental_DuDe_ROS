#pragma once

#include<vector>
using namespace std;

#include "Point.h"
using namespace mathtool;

#include "dude.h"

class c_cdt
{
public:

    bool build(c_dude& ap, c_polygon& sp, c_polygon& initPolygon);

protected:


};
