#include <string>
using namespace std;

//
//
// Save the rendering to postscript
//
//


void save2PS(const string& name);

//#endif
