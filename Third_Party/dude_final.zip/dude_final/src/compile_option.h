#ifndef _COMPILE_OPTION_H_
#define _COMPILE_OPTION_H_

#define GL_RENDERING 0 //openGL rendering
#define PS_RENDERING 0 //postscript rendering

#endif
