#ifndef _GLI_FONT_H_
#define _GLI_FONT_H_
#include <GL/gli.h>

//copy from Mason Woo, 1999
void setfont(const char* name, int size);
void drawstr(GLfloat x, GLfloat y, GLfloat z, const char* format);

#endif //_GLI_FONT_H_



