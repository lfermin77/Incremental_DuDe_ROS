#define  ExtApplFuncStoreTri_1

#define  ExtApplFuncStoreTri_2

#define  ExtApplFuncStoreQuad

#define  ExtApplFuncStoreVNormal

#define  ExtApplFuncStoreTVertex

#define  ExtApplFuncStoreVertex

#define  ExtApplFuncStorePnt

#define  ExtApplFuncNewInput

#define  ExtApplFuncDesperate

#define  ExtApplFuncReligious

#define  ExtApplFuncRestart

#define  ExtApplFuncDoneOneChain

#define  ExtApplFuncNextChain

#define  ExtApplFuncFinished

#define  ExtApplFuncTerminateProg

#define  ExtApplFuncResetAll

#define  ExtApplFuncNewPoly

#define  ExtApplFuncNewFace

#define  ExtApplFuncBeforeTriangulation

#define  ExtApplFuncDesperate3D

#define  ExtApplFuncReligious3D

#define  ExtApplFuncRestart3D

#define  ExtApplFuncDoneOneChain3D

#define  ExtApplFuncNextChain3D

#define  ExtApplFuncDoneOneFace

#define  ExtApplFuncDoneOneGroup

#define  ExtApplFuncFinished3D

